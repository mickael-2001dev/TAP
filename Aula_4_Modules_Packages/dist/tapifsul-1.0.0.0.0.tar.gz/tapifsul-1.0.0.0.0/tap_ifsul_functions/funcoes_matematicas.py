def somar(op1 , op2):
    print("Resultado da +: ",op1 + op2)

def multiplicar(op1 , op2):
    print("Resultado da *: ",op1 * op2)

def dividir(op1 , op2):
    print("Resultado da /: ",op1 / op2)

