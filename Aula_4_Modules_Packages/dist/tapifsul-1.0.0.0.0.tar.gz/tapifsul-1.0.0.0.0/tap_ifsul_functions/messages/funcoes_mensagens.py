def mensagem(texto):
    print(texto)